self.__precacheManifest = [
  {
    "revision": "ade1c42f56118e3b090c",
    "url": "https://ivanshavliuga.github.io/shulte2/css/app.78c088e5.css"
  },
  {
    "revision": "ade1c42f56118e3b090c",
    "url": "https://ivanshavliuga.github.io/shulte2/js/app.1211c8ab.js"
  },
  {
    "revision": "1f2b475c812942c18040",
    "url": "https://ivanshavliuga.github.io/shulte2/js/chunk-vendors.c1e8749d.js"
  },
  {
    "revision": "2bf2ead97e9e1d390996cda88da4f238",
    "url": "https://ivanshavliuga.github.io/shulte2/index.html"
  },
  {
    "revision": "333fe3e10f3cab8768e778d581c4b3c3",
    "url": "https://ivanshavliuga.github.io/shulte2/iv2.ico"
  }
];
