self.__precacheManifest = [
  {
    "revision": "f7978c43c55d17c0449d",
    "url": "https://ivanshavliuga.github.io/shulte2/css/app.74feebed.css"
  },
  {
    "revision": "f7978c43c55d17c0449d",
    "url": "https://ivanshavliuga.github.io/shulte2/js/app.9c8dc9a4.js"
  },
  {
    "revision": "1f2b475c812942c18040",
    "url": "https://ivanshavliuga.github.io/shulte2/js/chunk-vendors.c1e8749d.js"
  },
  {
    "revision": "038d32d63949c58219af76f481da42c0",
    "url": "https://ivanshavliuga.github.io/shulte2/index.html"
  },
  {
    "revision": "333fe3e10f3cab8768e778d581c4b3c3",
    "url": "https://ivanshavliuga.github.io/shulte2/iv2.ico"
  }
];
