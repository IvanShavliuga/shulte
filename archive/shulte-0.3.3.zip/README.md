## Таблиа Шульте
Генерируется случайным образом поле (5 на 5).
Собирайте числовую последовательность от 1 до 25 строго по порядку.
Используется vue.js и scss

Randomly generated field (5 by 5).
Collect the number sequence from 1 to 25 strictly in order.
Used vue.js and scss

## version 0.1.1

Решено изменить нумерацию версий
Прошлые реализации в каталоге ./archive/
Проект создан в учебных целях для изучения vue.js

https://ivanshavliuga.github.io

## version 0.3.0

Переход на третью версию Vue 3.0
Изменение дизайна и интерфейса. 

``` bash

# Project setup
npm install

# Compiles and hot-reloads for development
npm run serve

# Compiles and minifies for production
npm run build

# Lints and fixes files
npm run lint
```

## License
MIT
