<template>
  <board />
</template>

<script>
import board from "../components/Board.vue";
export default {
  components: {
    board,
  },
};
</script>
